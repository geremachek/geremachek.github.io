package main

import (
	"fmt"
	"os"
	"os/exec"
	"bufio"
	"github.com/geremachek/escape"
	"io/ioutil"
	"strings"
	"time"
	"math/rand"
)

const help = `Usage: tropic [OPTION]
A dead simple way to manage your wallpapers

--help, -h: Display this information
[a]dd [PATH]: Add a directory to the wallpaper library
[s]et [STYLE] [NAME]: Set the wallpaper to an imaage with the filename [NAME] with the style [STYLE]
[s]et [r]andom [STYLE] [DIRECTORY]: Set the wallpaper to an image in [DIRECTORY] with a random filename
[e]cho: Print out the name of the wallpaper
[l]ist: List all of the wallpapers in the library
[lib]rary: List all of the directories in the library
[r]emove [DIRECTORY]: Remove a directory from the library
[NONE]: Set the wallpaper to the image specified by a set command`

func read(path string) (lines []string) {
	file, _ := os.Open(path)
	line := bufio.NewScanner(file)
	for line.Scan() {
		lines = append(lines, line.Text())
	}
	file.Close()
	return
}

func write(path string, lines []string) {
	file, _ := os.Create(path)
	write := bufio.NewWriter(file)
	for _, line := range lines {
		fmt.Fprintln(write, line)
	}
	write.Flush()
}

func in(file string, array []string) (bool, int, string) {
	for i, elem := range array {
		selem := strings.Split(elem, "/")
		if file == selem[len(selem)-1] {
			return true, i, elem
		} else {
			continue
		}
	}
	return false, 0, ""
}

func feh(style string, path string) {
	feh := exec.Command("feh", "--no-fehbg", "--bg-" + style, path)
	feh.Start()
}

func getLib(path string) (lib []string) {
	file := read(path)
	for _, line := range file {
		files, _ := ioutil.ReadDir(line)
		for _, f := range files {
			if f.IsDir() {
				continue
			} else {
				lib = append(lib, line + "/" + f.Name())
			}
		}
	}
	return
}

func getDirLib(dir string, path string) (dirLib []string) {
	var split []string
	lib := getLib(path)
	for _, elem := range lib {
		split = strings.Split(elem, "/")
		if split[len(split)-2] == dir {
		dirLib = append(dirLib, elem)
		} else {
			continue
		}
	}
	return
}

func main() {
	tropicPath := os.Getenv("HOME") + "/.cache/tropic"
	wallPath := tropicPath + "/wallpaper"
	libPath := tropicPath + "/library"

	if _, err := os.Stat(tropicPath); os.IsNotExist(err) {
		os.Mkdir(tropicPath, 0775)
		os.Create(wallPath)
		os.Create(libPath)
	}

	argument := os.Args
	if len(argument) == 1 {
		file := read(wallPath)
		split := strings.Split(file[0], " ")
		if split[1] == "random" {
			lib := getLib(wallPath)
			r := rand.New(rand.NewSource(time.Now().UnixNano()))
			feh(split[0], lib[r.Intn(len(lib))])
		} else if string(split[1][:7]) == "random-" {
			dirLib := getDirLib(strings.Split(split[1], "-")[1], libPath)
			r := rand.New(rand.NewSource(time.Now().UnixNano()))
			rwall := dirLib[r.Intn(len(dirLib))]
			feh(split[0], rwall)
			fmt.Println(escape.Vint(32, 1) + "Wallpaper set to " + strings.Split(rwall, "/")[len(strings.Split(rwall, "/"))-1] + escape.Vint(0))

		} else {
			feh(split[0], split[1])
		}
	} else {
		if argument[1] == "--help" || argument[1] == "-h" {
			fmt.Println(help)
		} else if argument[1] == "add" || argument[1] == "a" {
			file := read(libPath)
			cwd, _ := os.Getwd()

			if string(argument[2][0]) == "/" {
				file = append(file, argument[2])
			} else {
				file = append(file, cwd + "/" + argument[2])
			}
			write(libPath, file)
		} else if argument[1] == "set" || argument[1] == "s" {
			lib := getLib(libPath)
			if len(argument) == 4 {
				if argument[2] == "random" || argument[2] == "r" {
					r := rand.New(rand.NewSource(time.Now().UnixNano()))
					rwall := lib[r.Intn(len(lib))]
					feh(argument[3], rwall)
					fmt.Println(escape.Vint(32, 1) + "Wallpaper set to " + strings.Split(rwall, "/")[len(strings.Split(rwall, "/"))-1] + escape.Vint(0))
					write(wallPath, []string{argument[3] + " random"})
				} else {
					in, index, path := in(argument[3], lib)
					if in {
						feh(argument[2], lib[index])
						write(wallPath, []string{argument[2] + " " + path})
					} else {
						fmt.Println(escape.Vint(31, 1) + "Error: '" + argument[3] + "' not found in library" + escape.Vint(31, 1))
					}
				}
			} else if len(argument) == 5 {
				if argument[2] == "random" || argument[2] == "r" {
					dirLib := getDirLib(argument[4], libPath)
					r := rand.New(rand.NewSource(time.Now().UnixNano()))
					rwall := dirLib[r.Intn(len(dirLib))]
					feh(argument[3], rwall)
					fmt.Println(escape.Vint(32, 1) + "Wallpaper set to " + strings.Split(rwall, "/")[len(strings.Split(rwall, "/"))-1] + escape.Vint(0))
					write(wallPath, []string{argument[3] + " random-" + argument[4]})
				}
			} else {
				fmt.Println(escape.Vint(31, 1) + "Error: Invalid number of arguments!" + escape.Vint(31, 1))
			}
		} else if argument[1] == "echo" || argument[1] == "e" {
			file := read(wallPath)
			name := strings.Split(file[0], " ")[1]
			if string(name[0]) == "r" {
				fmt.Println("Your wallpaper is random!")
			} else {
				path := strings.Split(string(name), "/")
				fmt.Println(path[len(path)-1])
			}
		} else if argument[1] == "remove" || argument[1] == "r" || argument[1] == "rm" {
			if len(argument) == 3 {
				file := read(libPath)
				for i, elem := range file {
					split := strings.Split(elem, "/")
					if split[len(split)-1] == argument[2] {
						write(libPath, append(file[:i], file[i+1:]...))
						break
					} else {
						continue
					}
				}
			} else {
				fmt.Println(escape.Vint(31, 1) + "Error: Invalid number of arguments!" + escape.Vint(31, 1))
			}
		} else if argument[1] == "library" || argument[1] == "lib" {
			file := read(libPath)
			for _, elem := range file {
				split := strings.Split(elem, "/")
				fmt.Println(split[len(split)-1])
			}
		} else if argument[1] == "list" || argument[1] == "l" || argument[1] == "ls" {
			files := getLib(libPath)
			file := read(wallPath)
			for _, elem := range files {
				name := strings.Split(file[0], " ")[1]
				split := strings.Split(elem, "/")
				if string(name) == elem {
					fmt.Print(escape.Vint(32, 1) + split[len(split)-1] + escape.Vint(0) + "  ")
				} else {
					fmt.Print(split[len(split)-1] + "  ")
				}
			}
			fmt.Println()
		}
	}
}
