# tropic

🖼️ tropic, a dead simple way to manage your wallpapers

# Dependencies

```
go get -u github.com/geremachek/escape
```

# Usage

```
A dead simple way to manage your wallpapers

--help, -h: Display this information
[a]dd [PATH]: Add a directory to the wallpaper library
[s]et [STYLE] [NAME]: Set the wallpaper to an imaage with the filename [NAME] with the style [STYLE]
[s]et [r]andom [STYLE] [DIRECTORY]: Set the wallpaper to an image in [DIRECTORY] with a random filename
[e]cho: Print out the name of the wallpaper
[l]ist: List all of the wallpapers in the library
[lib]rary: List all of the directories in the library
[r]emove [DIRECTORY]: Remove a directory from the library
[NONE]: Set the wallpaper to the image specified by a set command
```

# Dependencies

* ```feh``` for setting the background. xsetroot doesn't work well with compton and modern image formats.
