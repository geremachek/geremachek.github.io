import chunk
import pygame
import pygame.freetype

ship = pygame.image.load(r'media/argonaut2.png')
ship = pygame.transform.scale(ship, (800, 450))

pygame.freetype.init()
titlefont = pygame.freetype.Font('media/cyrillic_pixel-7.ttf', 50)

c = chunk.Chunk()

def draw_menu(s):
    c.Draw(s)
    surf = pygame.Surface((1050, 1050))
    surf.set_alpha(200)
    s.blit(surf, (0,0))

    title = titlefont.render("ARGONAUT", False, (255, 255, 255))
    s.blit(title, (100, 100))
    s.blit(ship, (80, -30))
