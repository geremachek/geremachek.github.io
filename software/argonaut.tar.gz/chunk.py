import pygame
import utils
from random import randint
from resources import BIOMES, t_LEAVES
from screen import TILE_SIZE, TOTAL_TILES

class Chunk:
    def __init__(self):
        chunk_biome = BIOMES[randint(0, len(BIOMES)-1)]

        self.matrix = []

        for i in range(0, TOTAL_TILES):
            row = []

            for i in range(0, TOTAL_TILES):
                row.append(chunk_biome.base.Mix())

            self.matrix.append(row)

        for struct, prob in chunk_biome.structs.items():
            struct.Fill(chunk_biome.base)

            for i, row in enumerate(self.matrix):
                for j, tile in enumerate(row):
                    if utils.chance(prob) and i <= (TOTAL_TILES-1)-struct.height and j <= (TOTAL_TILES-1)-struct.width:
                        for k, row in enumerate(struct.tiles):
                            self.matrix[i+k][j:j+struct.width] = row

    def Draw(self, scr):
        for i, row in enumerate(self.matrix):
            for j, tile in enumerate(row):
                pygame.draw.rect(scr, tile.color, pygame.Rect(j*TILE_SIZE, i*TILE_SIZE, TILE_SIZE, TILE_SIZE))

    def ScrollY(self, wmap, player, n):
        if (player.mapy == 0 and n == -1) or (player.mapy == len(wmap)-1 and n == 1):
            row = []

            for i in range(0, len(wmap[player.mapy])):
                if i == player.mapx:
                    row.append(Chunk())
                else:
                    row.append("")

            if n == -1:
                wmap.insert(0, row)
            else:
                wmap.append(row)
                player.mapy += 1
        else:
            player.mapy += n

            try:
                if wmap[player.mapy][player.mapx] == "":
                    wmap[player.mapy][player.mapx] = Chunk()
            except:
                pass

        self = wmap[player.mapy][player.mapx]

    def ScrollX(self, wmap, player, n):
        if (player.mapx == 0 and n == -1) or (player.mapx == len(wmap[player.mapy])-1 and n == 1):
            for i in range(len(wmap)):
                if i == player.mapy:
                    if n == -1:
                        wmap[i].insert(0, Chunk())
                    else:
                        wmap[i].append(Chunk())
                else:
                    if n == -1:
                        wmap[i].insert(0, "")
                    else:
                        wmap[i].append("")
        else:
            player.mapx += n

            try:
                if wmap[player.mapy][player.mapx] == "":
                    wmap[player.mapy][player.mapx] = Chunk()
            except:
                pass


        self = wmap[player.mapy][player.mapx]
