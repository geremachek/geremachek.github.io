import pygame
import time
import utils

class Tile:
    def __init__(self, name, color, attribs):
        self.name = name
        self.color = color
        self.attribs = attribs

    def Mix(self):
        return Tile(self.name, utils.color_mix(self.color), self.attribs)

class Structure:
    def __init__(self, width, height, tiles):
        self.width = width
        self.height = height
        self.tiles = tiles

    def Fill(self, bg):
        for i, row in enumerate(self.tiles):
            for j, tile in enumerate(row):
                if self.tiles[i][j].name == "null":
                    self.tiles[i][j] = bg.Mix()

class Biome:
    def __init__(self, base, structs):
        self.base = base
        self.structs = structs
