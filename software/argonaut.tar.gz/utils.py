from random import randint

def color_mix(color):
    new = color

    if 0 == randint(0, 4):
        r = randint(-7, 5)
        new = [color[0]+r, color[1]+r, color[2]+r]

        for i, elem in enumerate(new):
            if elem > 255:
                new[i] = 255
            elif elem < 0:
                new[i] = 0

    return (new[0], new[1], new[2])

def chance(n):
    return 0 == randint(0, n-1)
