import pygame
import time
from screen import TILE_SIZE, TOTAL_TILES

class Player:
    def __init__(self, xpos, ypos):
        self.x = xpos
        self.y = ypos

        self.mapx = 0
        self.mapy = 0

        self.rect = pygame.rect.Rect(((xpos*TILE_SIZE)+3, (ypos*TILE_SIZE)+3, 10, 10))

    def HandleMovement(self, chunk, wmap):
        key = pygame.key.get_pressed()

        up = key[pygame.K_UP]
        down = key[pygame.K_DOWN]
        left = key[pygame.K_LEFT]
        right = key[pygame.K_RIGHT]

        sx, sy = 0, 0

        if up and self.y > 0:
            sy = -1
        elif down and self.y < TOTAL_TILES-1:
            sy = 1
        elif left and self.x > 0:
            sx = -1
        elif right and self.x < TOTAL_TILES-1:
            sx = 1
        elif up:
            chunk.ScrollY(wmap, self, -1)
            sy = TOTAL_TILES-1
        elif down:
            chunk.ScrollY(wmap, self, 1)
            sy = -(TOTAL_TILES-1)
        elif left:
            chunk.ScrollX(wmap, self, -1)
            sx = TOTAL_TILES-1
        elif right:
            chunk.ScrollX(wmap, self, 1)
            #sx = -(TOTAL_TILES-1)

        if chunk.matrix[self.y + sy][self.x + sx].attribs["walkable"]:
            self.rect.move_ip(sx * TILE_SIZE, sy * TILE_SIZE)
            
            self.x += sx
            self.y += sy

        time.sleep(0.05)

    def Draw(self, scr, matrix):
        if not matrix[self.y][self.x].attribs["walkunder"]:
            pygame.draw.rect(scr, (0, 0, 0), self.rect)
