import pygame
import tiles
import player
import chunk
import time
import menu
from screen import WIN_SIZE

pygame.init()
screen = pygame.display.set_mode(WIN_SIZE)
running = True

clock = pygame.time.Clock()

world_map = [[chunk.Chunk()]]

me = player.Player(0, 0)

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_q:
                running = False

    if False:
        menu.draw_menu(screen)
    else:
        curr_chunk = world_map[me.mapy][me.mapx]

        curr_chunk.Draw(screen)
    
        me.HandleMovement(curr_chunk, world_map)
        me.Draw(screen, curr_chunk.matrix)

    pygame.display.flip()

    clock.tick(60)
