from tiles import Tile, Structure, Biome

t_NULL = Tile("null", (), {})
t_GRASS = Tile("grass", (55, 158, 45), {"walkable": True, "walkunder": False})
t_STONE = Tile("stone", (128, 128, 128), {"walkable": False, "walkunder": False})
t_LEAVES = Tile("leaves", (24, 99, 18), {"walkable": True, "walkunder": True})
t_WOOD = Tile("wood", (107, 68, 35), {"walkable": False, "walkunder": False})

t_SAND = Tile("sand", (206, 187, 64), {"walkable": True, "walkunder": False})
t_SANDSTONE = Tile("sandstone", (160, 147, 59), {"walkable": False, "walkunder": False})
t_BONE = Tile("bone", (250, 250, 250), {"walkable": False, "walkunder": False})

s_BOULDER = Structure(4, 2, [[t_NULL, t_STONE, t_STONE, t_NULL],
                            [t_STONE, t_STONE, t_STONE, t_STONE]])

s_TREE = Structure(3, 3, [[t_NULL, t_LEAVES, t_NULL],
                        [t_LEAVES, t_LEAVES, t_LEAVES],
                        [t_NULL, t_WOOD, t_NULL]])

s_SANDSTONE = Structure(1, 1, [[t_SANDSTONE]])

s_PALM = Structure(5, 4, [[t_NULL, t_LEAVES, t_LEAVES, t_LEAVES, t_NULL],
                        [t_LEAVES, t_NULL, t_WOOD, t_NULL, t_LEAVES],
                        [t_NULL, t_NULL, t_WOOD, t_NULL, t_NULL],
                        [t_NULL, t_NULL, t_WOOD, t_NULL, t_NULL]])

s_SKELETON = Structure(7, 7, [[t_BONE, t_NULL, t_BONE, t_NULL, t_BONE, t_NULL, t_NULL]])

b_FIELD = Biome(t_GRASS, {s_BOULDER: 200, s_TREE: 100})
b_DESERT = Biome(t_SAND, {s_SANDSTONE: 200, s_PALM: 500})

global BIOMES
BIOMES = [b_FIELD, b_DESERT]
