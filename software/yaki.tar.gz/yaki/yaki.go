package main

import (
	"fmt"
	"strings"
	"os"
	"bufio"
	"encoding/json"
	"github.com/geremachek/escape"
	"io/ioutil"
	"strconv"
)

const help = `Usage: yaki [OPTION] [PATH]
Organize your life

--help, --h: Display this information
[l]ist [PATH]: List all of the items and groups in [PATH]
[a]dd [PATH] [STRING]: Create a new item or group
[t]ag [NAME] [COLOR] [SYMBOL]: Create a new tag
[r]emove [PATH]: Remove an item or group
[e]dit [PATH] [NAME/STRING]: Edit the text of an item or name of a group
[TAG-NAME] [PATH]: Apply tag to an item
[NONE]: List the "root" group
`

type Tag struct {
	Color int `json:"color"`
	Name string `json:"name"`
	Symbol string `json:"symbol"`
}

type Item struct {
	Text string `json:"text"`
	Tag Tag `json:"tag"`
}

type Group struct {
	Name string `json:"name"`
	Items []Item `json:"items"`
	Groups []Group `json:"groups"`
}

func in(item string, array []Group) (bool, int) {
	for i, elem := range array {
		if item == elem.Name {
			return true, i
		} else {
			continue
		}
	}
	return false, 0
}

func splitRGB(srgb string) (rgb []int) {
	for _, elem := range strings.Split(srgb, ",") {
		n, _ := strconv.Atoi(elem)
		rgb = append(rgb, n)
	}
	return
}

func inTags(item string, array []Item) (bool, int) {
	for i, elem := range array {
		if item == elem.Tag.Name {
			return true, i
		} else {
			continue
		}
	}
	return false, 0
}

func lsGroups(groups []Group, groupColor string, groupFormat string) {
	rgb := splitRGB(groupColor)
	var format int
	if groupFormat == "default" || groupFormat == "" {
		format = 20
	} else if groupFormat == "bold" {
		format = 1
	} else if groupFormat == "underline" {
		format = 4
	} else if groupFormat == "reverse" {
		format = 7
	} else if groupFormat == "italic" {
		format = 3
	}
	for _, group := range groups {
		fmt.Print(" \u2219 ")
		fmt.Println(escape.Vint(38,2,rgb[0],rgb[1],rgb[2],format) + group.Name + escape.Vint(0))
	}
}

func rstrx(str string, x int) (out string) {
	for i := 1; i <= x; i++ {
		out = out + " "
	}
	return
}

func lsItems(items []Item, itemColor string, itemFormat string, numberBool bool, numberColor string) {
	rgb := splitRGB(itemColor)
	rgb2 := splitRGB(numberColor)
	var format int
	var x int = 2
	if itemFormat == "default" || itemFormat == "" {
		format = 20
	} else if itemFormat == "bold" {
		format = 1
	} else if itemFormat == "underline" {
		format = 4
	} else if itemFormat == "reverse" {
		format = 7
	} else if itemFormat == "italic" {
		format = 3
	}
	for i, item := range items {
		if numberBool {
			if len(strconv.Itoa(i+1)) == 2 {
				x = len(strconv.Itoa(i+1))-1
			}
			fmt.Print(escape.Vint(38,2,rgb2[0],rgb2[1],rgb[2],1) + " " + strconv.Itoa(i+1) + rstrx(" ", x) + escape.Vint(0))
		} else {
			fmt.Print(" \u2219 ")
		}
		fmt.Print(escape.Vint(38,2,rgb[0],rgb[1],rgb[2],format) + item.Text + escape.Vint(0))
		fmt.Println(escape.Vint(38,5,item.Tag.Color) + " " + item.Tag.Symbol + escape.Vint(0))
	}
}

func list(list Group, path string, groupColor string, groupFormat string, itemColor string, itemFormat string, numberBool bool, numberColor string) {
	if path == "" {
		fmt.Println()
		lsGroups(list.Groups, groupColor, groupFormat)
		lsItems(list.Items, itemColor, itemFormat, numberBool, numberColor)
		fmt.Println()
	} else {
		var currentGroup Group = list
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = currentGroup.Groups[index]
			}
		}
		fmt.Println()
		lsGroups(currentGroup.Groups, groupColor, groupFormat)
		lsItems(currentGroup.Items, itemColor, itemFormat, numberBool, numberColor)
		fmt.Println()

	}
}

func addItem(list *Group, newItem Item, path string) Group {
	var currentGroup *Group = list
	if path == "" {
		currentGroup.Items = append(currentGroup.Items, newItem)
	} else {
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		currentGroup.Items = append(currentGroup.Items, newItem)
	}

	return *currentGroup
}

func addGroup(list *Group, newGroup Group, path string) Group {
	var currentGroup *Group = list
	if path == "" {
		currentGroup.Groups = append(currentGroup.Groups, newGroup)
	} else {
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		currentGroup.Groups = append(currentGroup.Groups, newGroup)
	}

	return *currentGroup
}

func addTag(list *Group, newTag Tag, path string) Group {
	var currentGroup *Group = list
	pathArr := strings.Split(path, "/")
	itemNumber, _ := strconv.Atoi(pathArr[len(pathArr)-1])
	if path == "" {
		currentGroup.Items[itemNumber-1].Tag = newTag
	} else {
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		currentGroup.Items[itemNumber-1].Tag = newTag
	}

	return *currentGroup
}

func removeItem(list *Group, path string) Group {
	var currentGroup *Group = list
	pathArr := strings.Split(path, "/")
	itemNumber, _ := strconv.Atoi(pathArr[len(pathArr)-1])
	if path == "" {
		currentGroup.Items = append(currentGroup.Items[:itemNumber-1], currentGroup.Items[itemNumber:]...)
	} else {
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		currentGroup.Items = append(currentGroup.Items[:itemNumber-1], currentGroup.Items[itemNumber:]...)
	}

	return *currentGroup
}

func removeGroup(list *Group, path string) Group {
	var currentGroup *Group = list
	pathArr := strings.Split(path, "/")
	loopArr := pathArr[:len(pathArr)-1]
	group := pathArr[len(pathArr)-1]
	if len(pathArr) == 1 {
		_, i := in(group, currentGroup.Groups)
		currentGroup.Groups = append(currentGroup.Groups[:i], currentGroup.Groups[i+1:]...)
	} else {
		for _, elem := range loopArr {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		_, i := in(group, currentGroup.Groups)
		currentGroup.Groups = append(currentGroup.Groups[:i], currentGroup.Groups[i+1:]...)
	}

	return *currentGroup
}

func editItem(list *Group, newText string, path string) Group {
	var currentGroup *Group = list
	var index int
	array := strings.Split(path, "/")
	if len(array) == 1 {
		strindex, _ := strconv.Atoi(strings.Join(array, ""))
		index = strindex
	} else {
		strindex, _ := strconv.Atoi(array[len(array)-1])
		index = strindex
	}
	if path == "" {
		currentGroup.Items[index-1].Text = newText
	} else {
		for _, elem := range strings.Split(path, "/") {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		currentGroup.Items[index-1].Text = newText
	}

	return *currentGroup
}

func editGroup(list *Group, newName string, path string) Group {
	var currentGroup *Group = list
	pathArr := strings.Split(path, "/")
	loopArr := pathArr[:len(pathArr)-1]
	group := pathArr[len(pathArr)-1]
	if len(pathArr) == 1 {
		_, i := in(group, currentGroup.Groups)
		currentGroup.Groups[i].Name = newName
	} else {
		for _, elem := range loopArr {
			in, index := in(elem, currentGroup.Groups)
			if in {
				currentGroup = &currentGroup.Groups[index]
			}
		}
		_, i := in(group, currentGroup.Groups)
		currentGroup.Groups[i].Name = newName
	}

	return *currentGroup
}

func newTag(tags Group, newTag Tag) (out Group) {
	out = tags
	out.Items = append(out.Items, Item{Text: "", Tag: newTag})
	return
}

func writeJSON(root Group, path string) error {
	json, _ := json.Marshal(root)

	file, err := os.Create(path)
	if err != nil {
		return err
	}
	defer file.Close()
	w := bufio.NewWriter(file)
	fmt.Fprintln(w, string(json))

	return w.Flush()
}

func readJSON(path string) (out Group, err error) {
	file, err := os.Open(path)
	if err != nil {
		return Group{Name: "",Items: []Item{},Groups: []Group{}}, err
	}
	defer file.Close()

	byteValue, _ := ioutil.ReadAll(file)
	json.Unmarshal(byteValue, &out)

	return out, err
}

func parseConfig(path string) (gc string, ga string, ic string, ia string, nb bool, nc string) {
	file, _ := os.Open(path)
	line := bufio.NewScanner(file)
	for line.Scan() {
		commands := strings.Split(line.Text(), " ")
		if commands[0] == "group-color" {
			gc = commands[1]
		} else if commands[0] == "group-fmt" {
			ga = commands[1]
		} else if commands[0] == "item-color" {
			ic = commands[1]
		} else if commands[0] == "item-fmt" {
			ia = commands[1]
		} else if commands[0] == "number" {
			if commands[1] == "true" {
				nb = true
			} else if commands[1] == "false" {
				nb = false
			} else {
				nb = false
			}
		} else if commands[0] == "number-color" {
			nc = commands[1]
		} else {
			continue
		}
	}

	return
}

func main() {
	configPATH := os.Getenv("HOME") + "/.yakirc"
	yakiPATH := os.Getenv("HOME") + "/.cache/yaki/"
	fsPATH := yakiPATH + "yaki.json"
	tagPATH := yakiPATH + "tags.json"
	if _, err := os.Stat(yakiPATH); os.IsNotExist(err) {
		os.MkdirAll(yakiPATH, 0755)
		os.Create(fsPATH)
		os.Create(tagPATH)
	}

	groupColor := "148,191,243"
	groupFormat := "bold"
	itemColor := "default"
	itemFormat := "default"
	numberBool := false
	numberColor := "default"

	if _, err := os.Stat(configPATH); !(os.IsNotExist(err)) {
		groupColor, groupFormat, itemColor, itemFormat, numberBool, numberColor = parseConfig(configPATH)
	}

	root, _ := readJSON(fsPATH)
	tags, _ := readJSON(tagPATH)
	var blank Tag = Tag{Color: 300, Name: "", Symbol: ""}
	arguments := os.Args

	if len(arguments) == 1 {
		list(root, "", groupColor, groupFormat, itemColor, itemFormat, numberBool, numberColor)
	} else if arguments[1] == "--help" || arguments[1] == "-h" {
		fmt.Print(help)
	} else if arguments[1] == "ls" || arguments[1] == "l" || arguments[1] == "list" {
		if len(arguments) == 2 {
			list(root, "", groupColor, groupFormat, itemColor, itemFormat, numberBool, numberColor)
		} else {
			list(root, arguments[2], groupColor, groupFormat, itemColor, itemFormat, numberBool, numberColor)
		}
	} else if arguments[1] == "tag" || arguments[1] == "t" {
		if len(arguments) == 5 {
			color, _ := strconv.Atoi(os.Args[3])
			tag := newTag(tags, Tag{Color: color, Name: os.Args[2], Symbol: os.Args[4]})
			writeJSON(tag, tagPATH)
		} else {
			fmt.Println(escape.Vint(31, 1) + "You must provide 3 arguments to tag!" + escape.Vint(0))
		}
	} else if arguments[1] == "add" || arguments[1] == "a" {
		if strings.Contains(arguments[2], "/") {
			if len(arguments) == 3 {
				path := strings.Split(arguments[2], "/")
				var name string = path[len(path)-1]
				if name == "" {
					name = path[len(path)-2]
				}
				addGroup(&root, Group{Name: name, Items: []Item{}, Groups: []Group{}}, arguments[2])
			} else {
				addItem(&root, Item{Text: strings.Join(arguments[3:], " "), Tag: blank}, arguments[2])
			}
		} else {
			addItem(&root, Item{Text: strings.Join(arguments[2:], " "), Tag: blank}, arguments[2])
		}
		writeJSON(root, fsPATH)
	} else if arguments[1] == "remove" || arguments[1] == "r" || arguments[1] == "rm" {
		if _, err := strconv.Atoi(string(arguments[2][len(arguments[2])-1])); err == nil {
			removeItem(&root, arguments[2])
		} else {
			removeGroup(&root, arguments[2])
		}
		writeJSON(root, fsPATH)
	} else if arguments[1] == "edit" || arguments[1] == "e" || arguments[1] == "ed" {
		if _, err := strconv.Atoi(string(arguments[2][len(arguments[2])-1])); err == nil {
			editItem(&root, strings.Join(arguments[3:], " "), arguments[2])
		} else {
			editGroup(&root, arguments[3], arguments[2])
		}
		writeJSON(root, fsPATH)
	} else if in, index := inTags(arguments[1], tags.Items); in {
		addTag(&root, tags.Items[index].Tag, arguments[2])
		writeJSON(root, fsPATH)
	} else {
		fmt.Println(escape.Vint(31, 1) + "Error: '" + arguments[1] + "' is not a valid command, try '--help', for help" + escape.Vint(0))
	}

}
