# yaki

🍱 yaki, organize your life 

<img src="https://raw.githubusercontent.com/geremachek/yaki/master/yaki.png" alt="todo"/>

# Dependencies

```
go get -u github.com/geremachek/escape
```

# What is it?
 
yaki is an organizer. The main components of udon are ```groups```, ```items```, and ```tags```. ```groups``` can contain any number of ```groups``` and ```items```. An ```item``` can have a ```tag``` witch is displayed next to the ```item``` when it is displayed.

# Usage

```
Usage: yaki [OPTION] [PATH]
Organize your life

--help, --h: Display this information
[l]ist [PATH]: List all of the items and groups in [PATH]
[a]dd [PATH] [STRING]: Create a new item or group
[t]ag [NAME] [COLOR] [SYMBOL]: Create a new tag
[r]emove [PATH]: Remove an item or group
[e]dit [PATH] [NAME/STRING]: Edit the text of an item or name of a group
[TAG-NAME] [PATH]: Apply tag to an item
[NONE]: List the "root" group
```

# Basic Usage

### Listing

List The root group

```yaki ls```

List the ```foo``` group

```yaki ls foo```

List the ```foo/bar``` group

```yaki ls foo/bar```

### Creating new items and groups

Create a new item in the root group

```yaki add Hello, World```

Create a new group in the root group

```yaki add hello/```

Create a new item in the ```hello``` group

```yaki add hello/ Hello, World```


Create a new group in the ```hello``` group

```yaki add hello/world```

### Tags

Create a new tag

```yaki tag done 70 ✔```

Apply a tag to an item

```yaki done 1```

### Removing items

Removing an item

```yaki remove 1```

Removing a group

```yaki remove hello```

Removing an item in a group

```yaki remove hello/2```

### Editing

Editing an item

```yaki edit 1 Hello, World```

Editing a group

```yaki edit helo hello```
