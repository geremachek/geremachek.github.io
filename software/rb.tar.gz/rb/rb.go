package main

import (
	"fmt"
	"github.com/gookit/color"
	"os"
	"io/ioutil"
)

func getHomeDir() (string) {
	home := os.Getenv("HOME")
	suser := os.Getenv("SUDO_USER")
	ostype := os.Getenv("OSTYPE")
	var out string

	if suser != "" {
		if ostype[:5] == "linux" || ostype[:6] == "netbsd" || ostype[:7] == "openbsd" || ostype[:7] == "freebsd" {
			out = "/home/" + suser
		} else if ostype[:4] == "darwin" {
			out = "/Users/" + suser
		}
	} else {
		out = home
	}

	return out
}

func Exists(name string) (bool) {
	if _, err := os.Stat(name); err != nil {
		if os.IsNotExist(err) {
			return false
		}
	}
	return true
}

func main() {
	if len(os.Args) > 1 {
		if os.Args[1] == "-h" {
			fmt.Println("Usage: rb [OPTION]... [FILE]...")
			fmt.Println("Delete [FILE]s or move them to a cache\n")
			fmt.Println("  move, m\t move [FILE]s to the 'recycle bin'")
			fmt.Println("  remove, r\t remove [FILE]s")
			fmt.Println("  empty, e\t empty the 'recycle bin'")
			fmt.Println("  delete, d\t remove [FILE]s from the 'recylce bin'")
			fmt.Println("  ls, l\t\t list files in the 'recylce bin'")
			fmt.Println("  save, s\t return the [FILE]s to the current directory from the 'recycle bin'. If no arguments are supplied, the entire bin is dumped")

		} else if os.Args[1] == "move" || os.Args[1] == "m" {
			for _, elem := range os.Args[2:] {
				if Exists(elem) {
					os.Rename(elem, getHomeDir() + "/.cache/rb/" + elem)
				} else {
					fmt.Println("Error: " + elem + " can not be found")
					os.Exit(0)
				}
			}
		} else if os.Args[1] == "remove" || os.Args[1] == "r" {
			for _, elem := range os.Args[2:] {
				if Exists(elem) {
					os.RemoveAll(elem)
				} else {
					fmt.Println("Error: " + elem + " can not be found")
					os.Exit(0)
				}
			}
		} else if os.Args[1] == "empty" || os.Args[1] == "e" {
			files, _ := ioutil.ReadDir(getHomeDir() + "/.cache/rb")
			for _, elem := range files {
				os.RemoveAll(getHomeDir() + "/.cache/rb/" + string(elem.Name()))
			}
		} else if os.Args[1] == "delete" || os.Args[1] == "d" {
			for _, elem := range os.Args[2:] {
				if Exists(getHomeDir() + "/.cache/rb/" + elem) {
					os.RemoveAll(getHomeDir() + "/.cache/rb/" + elem)
				} else {
					fmt.Println(" Error: " + elem + " can not be found")
					os.Exit(0)
				}
			}
		} else if os.Args[1] == "ls" || os.Args[1] == "l" {
			files, _ := ioutil.ReadDir(getHomeDir() + "/.cache/rb")
			for _, elem := range files {
				fmt.Print(" \u2219 ")
				if elem.IsDir() {
					color.New(color.FgBlue, color.Bold).Println(string(elem.Name()))
				} else {
					fmt.Println(string(elem.Name()))
				}
			}
		} else if os.Args[1] == "save" || os.Args[1] == "s" {
			if len(os.Args) != 2 {
				for _, elem := range os.Args[2:] {
					if Exists(getHomeDir() + "/.cache/rb/" + elem) {
						os.Rename(getHomeDir() + "/.cache/rb/" + elem, os.Getenv("PWD") + "/" + elem)
					} else {
						fmt.Println(" Error: " + elem + " can not be found")
						os.Exit(0)
					}
				}
			} else {
				files, _ := ioutil.ReadDir(getHomeDir() + "/.cache/rb")
				for _, elem := range files {
					os.Rename(getHomeDir() + "/.cache/rb/" + string(elem.Name()), os.Getenv("PWD") + "/" + string(elem.Name()))
				}
			}
		} else {
			fmt.Println("Error: invalid option, use '-h' for help")
		}
	} else {
		fmt.Println("Error: you must supply arguments. use '-h' for help")
	}
}
