![rb](https://github.com/geremachek/rb/raw/master/logo.png "rb")

this is not a suckless project, I just like the logo design

🗑️ ```rb```, or "recycle bin" is a reimaging of rm

# Why Use rb?
```rb``` is minimal and stays out of your way, but could save your life (figuratively).

```rb``` works like rm, but instead of deleteing your files, it moves them to the "recylce bin" in ```~/.cache/rb```. You can delete, retrieve, or list files in the recylce bin. You can also just empty it completely 

# Usage
```
Usage: rb [OPTION]... [FILE]...
Delete [FILE]s or move them to a cache

  move, m	 move [FILE]s to the 'recycle bin'
  remove, r	 remove [FILE]s
  empty, e	 empty the 'recycle bin'
  delete, d	 remove [FILE]s from the 'recylce bin'
  ls, l		 list files in the 'recylce bin'
  save, s	 return the [FILE]s to the current directory from the 'recycle bin'. If no arguments are supplied, the entire bin is dumped
```

# Configuration
To save time, you can add this to your ```.shellrc```:
```
alias rm='rb m'
```
or
```
alias rm='rb'
```

You can also add this to any script that runs on startup
```
rb empty
```
