<h1 align="center">flip(1) 📖</h1>

<p align="center">A simple command that lets you "flip" through files</p>
<br><br>

**Usage:**

```
flip [FILE...]
```

**Why:**

Maybe you want to review some information or deliver a quick and minimal presentation.
Also, it's really minimal. (~110 lines of pure python + curses)
