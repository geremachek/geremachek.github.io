# tt

A time calculator

# Installation

Download the binary:

```
wget https://raw.githubusercontent.com/geremachek/tt/master/tt
```

Add it to your path:

```
sudo mv tt /usr/bin/tt
```

# Usage

tt is written to support US and international time.

To use us time pass the ```-u``` flag. it looks like this

```bash
tt -u 9am 9pm
```

You can specifiy minutes and seconds if you like

```bash
tt -u 9am 10:55am
```

To calculate the differnce from the current time, supply only one argument

```
tt -u 5pm # When do I get out of work?
```

If you live in the land of free like me, you can add this you your ```.shellrc```

```
alias t="tt -u"
```
