package main

import (
	"fmt"
	"strings"
	"strconv"
	"os"
	"flag"
	"github.com/gookit/color"
	"time"
)

var (
	hour, hour2, oHour int
	minute, minute2, oMinute int
	second, second2, oSecond int
	us bool
	totalSecs, totalMins int
)

func pos(n int) int {
	if n < 0 {
		out := (n - n) - n
		return out
	} else {
		return n
	}
}

func splitTime(time []string) (int, int, int) {
	var x,y,z int
	for i, elem := range(time) {
		if i == 0 {
			x, _ = strconv.Atoi(elem)
		} else if i == 1 {
			y, _ = strconv.Atoi(elem)
		} else if i == 2 {
			z, _ = strconv.Atoi(elem)
		} else {
			fmt.Println("Error")
			os.Exit(0)
		}

	}

	return x, y, z
}

func us2Int(time int, px string) (int) {
	var out int

	if px == "am" {
		if time == 12 {
			out = 0
		} else {
			out = time
		}
	} else if px == "pm" {
		if time == 12 {
			out = time
		} else {
			out = time+12
		}
	}

	return out
}

func diffTime(time1 string, time2 string, m1 string, m2 string) (int, int, int) {
	hour, minute, second = splitTime(strings.Split(time1, ":"))
	hour2, minute2, second2 = splitTime(strings.Split(time2, ":"))

	if !(m1 == "" && m2 == "") {
		hour = us2Int(hour, m1)
		hour2 = us2Int(hour2, m2)
	}

	totalSecs = pos((((hour*60)*60) + (minute*60) + second) - (((hour2*60)*60) + (minute2*60) + second2))

	var (
		rh int
		rm int
		rs int
	)

	if (totalSecs/3600) >= 1 {
		rh = (totalSecs/3600)
	}

	if (totalSecs/60) >= 1 {
		rm = (totalSecs/60)-(totalSecs/3600)*60
	}

	rs = totalSecs-((rh*3600)+(rm*60))

	return rh, rm, rs
}


func main() {
	flag.BoolVar(&us, "u", false, "US Time")
	flag.Parse()

	if us {
		time1 := string(os.Args[2])
		xm1 := string(time1[len(time1)-2:])
		timex1 := strings.Split(time1, xm1)[0]

		if len(os.Args) == 4 {
			time2 := string(os.Args[3])
			xm2 := string(time2[len(time2)-2:])
			timex2 := strings.Split(time2, xm2)[0]

			oHour, oMinute, oSecond = diffTime(timex1, timex2, xm1, xm2)
		} else if len(os.Args) == 3 {
			now := time.Now()

			timex2 := string(now.Format("3:4:5"))
			xm2 := string(now.Format("pm"))

			oHour, oMinute, oSecond = diffTime(timex1, timex2, xm1, xm2)
		} else {
			fmt.Println("Error")
			os.Exit(0)
		}
	} else {
		if len(os.Args) == 3 {
			oHour, oMinute, oSecond = diffTime(string(os.Args[1]), string(os.Args[2]), "", "")
		} else if len(os.Args) == 2 {
			now := time.Now()
			oHour, oMinute, oSecond = diffTime(string(os.Args[1]), string(now.Format("15:4:5")), "", "")
		}
	}

	fmt.Print("\u25B6 ")

	if oHour > 0 {
		color.Magenta.Print(oHour)
		color.Bold.Print(" hour(s) ")
	}
	if oMinute > 0 {
		color.Green.Print(oMinute)
		color.Bold.Print(" minute(s) ")
	}
	if oSecond > 0 {
		color.Yellow.Print(oSecond)
		color.Bold.Print(" second(s) ")
	}

	fmt.Print("\n")

}
